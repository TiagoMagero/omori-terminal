#!/bin/sh
set -eu
motion_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
motion_entry=$motion_dir/motion
if [ ! -f "$motion_entry" ]; then printf '%s\n' 'motion not found.' >&2; exit 1; fi
chmod u+x "$motion_entry"
motion_quoted=$(printf '%s' "$motion_entry" | sed "s/'/'\\\\''/g")
motion_stamp=$(date '+%Y%m%d%H%M%S')-$$
motion_install_profile() {
    motion_profile=$1
    motion_kind=$2
    if [ -f "$motion_profile" ] && grep -Fq '# >>> OMORI MOTION >>>' "$motion_profile"; then
        printf 'Already configured: %s\n' "$motion_profile"
        return
    fi
    mkdir -p "$(dirname -- "$motion_profile")"
    if [ -f "$motion_profile" ]; then
        cp -p "$motion_profile" "$motion_profile.omori-backup-$motion_stamp"
    fi
    {
        printf '\n%s\n' '# >>> OMORI MOTION >>>'
        if [ "$motion_kind" = fish ]; then
            printf '%s\n' 'if status is-interactive; and test -t 1'
            printf "    sh '%s'\n" "$motion_quoted"
            printf '%s\n' 'end'
        else
            printf '%s\n' 'case $- in *i*)'
            printf '%s\n' '    if [ -t 1 ] && [ "${_OMORI_MOTION_PID-}" != "$$" ]; then'
            printf '%s\n' '        _OMORI_MOTION_PID=$$'
            printf "        sh '%s'\n" "$motion_quoted"
            printf '%s\n' '    fi' ';; esac'
        fi
        printf '%s\n' '# <<< OMORI MOTION <<<'
    } >> "$motion_profile"
    printf 'Configured: %s\n' "$motion_profile"
}
motion_install_profile "${HOME:?}/.bashrc" posix
motion_install_profile "$HOME/.bash_profile" posix
motion_install_profile "${ZDOTDIR:-$HOME}/.zshrc" posix
motion_install_profile "${XDG_CONFIG_HOME:-$HOME/.config}/fish/config.fish" fish
printf '%s\n' 'Done. Open a new terminal. Keep this folder in the same location.'
