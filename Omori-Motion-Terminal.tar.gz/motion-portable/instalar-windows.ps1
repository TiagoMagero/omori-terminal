#requires -Version 5.1
[CmdletBinding()]
param([string] $DocumentsDirectory = [Environment]::GetFolderPath('MyDocuments'))
$ErrorActionPreference = 'Stop'
$motionScript = Join-Path $PSScriptRoot 'motion.ps1'
if (-not (Test-Path -LiteralPath $motionScript -PathType Leaf)) { throw 'motion.ps1 nao encontrado.' }
$escapedScript = $motionScript.Replace("'", "''")
$block = @'

# >>> OMORI MOTION >>>
if ([Environment]::UserInteractive -and -not [Console]::IsOutputRedirected -and -not ([Environment]::GetCommandLineArgs() -match '(?i)^-(noninteractive|noni|command.*|c|file|f)$')) {
    & '__SCRIPT__'
}
# <<< OMORI MOTION <<<
'@.Replace('__SCRIPT__', $escapedScript)
$profiles = @(
    (Join-Path $DocumentsDirectory 'WindowsPowerShell\profile.ps1'),
    (Join-Path $DocumentsDirectory 'PowerShell\profile.ps1')
)
foreach ($profilePath in $profiles) {
    $encoding = [Text.UTF8Encoding]::new($true)
    if (Test-Path -LiteralPath $profilePath) {
        $bytes = [IO.File]::ReadAllBytes($profilePath)
        if ($bytes.Length -ge 2 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254) {
            $encoding = [Text.UnicodeEncoding]::new($false, $true)
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 254 -and $bytes[1] -eq 255) {
            $encoding = [Text.UnicodeEncoding]::new($true, $true)
        } elseif ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) {
            $encoding = [Text.UTF8Encoding]::new($true)
        } else {
            try {
                [void][Text.UTF8Encoding]::new($false, $true).GetString($bytes)
                $encoding = [Text.UTF8Encoding]::new($false)
            } catch { $encoding = [Text.Encoding]::Default }
        }
        if ($encoding.GetString($bytes).Contains('# >>> OMORI MOTION >>>')) {
            Write-Host "Ja configurado: $profilePath"
            continue
        }
        $backupPath = $profilePath + '.omori-backup-' + [Guid]::NewGuid().ToString('N')
        [IO.File]::Copy($profilePath, $backupPath, $false)
        Write-Host "Backup: $backupPath"
    } else {
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($profilePath))
    }
    [IO.File]::AppendAllText($profilePath, $block + [Environment]::NewLine, $encoding)
    Write-Host "Configurado: $profilePath"
}
Write-Host 'Pronto. Abra outro PowerShell. Mantenha esta pasta no mesmo lugar.'
Write-Host 'Para CMD, use abrir-cmd.cmd ou configure o comando inicial explicado no LEIA-ME.txt.'
