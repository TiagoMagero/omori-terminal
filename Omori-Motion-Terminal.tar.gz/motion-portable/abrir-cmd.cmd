@echo off
"%ComSpec%" /k call "%~dp0motion.cmd"
