@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -File "%~dp0instalar-windows.ps1"
if errorlevel 1 (echo Falha na configuracao. & pause & exit /b 1)
pause
